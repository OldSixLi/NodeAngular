//获取当前网址，如： http://localhost:8083/console/admin/test.jsp
var curWwwPath=window.document.location.href;
//获取主机地址之后的目录，如： console/test/
var pathName=window.document.location.pathname;
var pos=curWwwPath.indexOf(pathName);
//获取主机地址，如： http://localhost:8083
var localhostPaht=curWwwPath.substring(0,pos);
//获取带"/"的项目名，如：/console
var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
//获取项目地址
var projectPath = localhostPaht+projectName;
/**
 * 资源服务器地址
 */
/*var resourceHost = "http://192.168.106.32:8080/res/";*/

///////////////////图片上传///////////////////////////////////
/**
 * 为某个按钮绑定上传图片
 * 
 * @param validate 校验规则 {width:...,height:...}
 * @param saveInfo 保存规则 {width:...,height:...}
 * @param watermark 水印 
 * @param floor 新开窗口所属层数
 * @param callback 回调函数 
 */
function UploadIMG(validate, saveInfo, watermark,floor,callback){
	var diag = new top.httc();
	diag.two = true;
	diag.Width = 400;
	diag.Height = 400;
  	diag.Title = "上传图像";
  	//经zdialog源码研究发现在zdialog打开的窗口下获取父级元素时用parent获取到的是顶层父级元素，所以得传过去打开窗口所属层数，便于在新开窗口下处理相应层数下的元素
  	var url = projectPath + "/tool/toImageUpload?validate="+validate+"&&saveInfo="+saveInfo+"&&watermark="+encodeURI(encodeURI(watermark))+"&&floor="+floor+"&&callback="+callback;
	diag.URL = url;
	diag.CancelEvent = function(){ 
		diag.close();
	 };
	diag.show();
   }

/**
 * 上传图片文件
 * 
 * @param validate 校验规则 {width:...,height:...}
 * @param saveInfo 保存规则 {width:...,height:...}
 * @param watermark 水印
 * @param blankURL 跨域异步所需的本地url地址
 * @param callback 上传结束后的回调方法，接受参数格式：{success: true/false, message: ..., files: [{url:..., mime:..., fileSize:..., width:..., height:..., backgroundColor:...}]}
 * @returns
 */
var uploadImage = function(validate, saveInfo, watermark, blankURL, callback) {
	if(validate=='666'&&saveInfo=='666'){
	//NOTE:666没啥实际意义,就是后来升级图片管理功能时,和原来的做个区分(用户点击缩略图时使用)

	
	var src=$(watermark).attr('src');//地址
	var remark=$(watermark).attr('alt');//备注
	var imgId=$(watermark).attr('data-imgId');
	//模拟真实上传的结果
	var imgModel={
		files:[{
			url:src,//除了这个有用,其他的都没啥用
			backgroundColor:"",
			fileSize:"",
			height:0,
			width:0,
			ysName:""
		}],
		success:true
	};

	infoImgShow();//展示相关的区域
	var des = $("#imgUploadBlock").find("#descript");
	des.empty();
	$("<img>").attr("src", imgModel.files[0].url)
	.addClass('img-responsive img-thumbnail')
	.appendTo(des);
	$("#imgUploadBlock").find("#spanImgInfo").text(remark);
	$("#imgUploadBlock").
	find("#btnImgDelete").
	attr("data-delete-id",imgId);

	$("#btnImgUse").unbind();
	// if($("#btnImgUse").attr('data-fun')=='0'){
	//点击应用按钮进行操作
	$("#btnImgUse").on('click',function (e) { 
		e.preventDefault();
		//将原来的回调函数在___createUpLoadDalogNew___中调用,修改为在按钮中调用
		callback(imgModel);
	});


	//点击删除按钮进行的操作
	$("#btnImgDelete").one('click',function (e) { 
		e.preventDefault();
		//删除操作
		var  deleteId=$(this).attr("data-delete-id");
		$.ajax({
			type: "POST",
			url: "knowledge/article/insertOrDelImage",
			data: {
			   id: deleteId
			},
			dataType: "json",
			success: function(data, textStatus, jqXHR) {
			  if (data != null && data != "") {
				if (data.success) {
				  imgBlockClear();
				  //TODO getToday() 重新请求今天的URL
				  getImgListByDate(getToday());
				} 
			  }  
			} 
		  });
	});
// 	$("#btnImgUse").attr('data-fun',1);
// }
	}
	else{
	
	//马少博 2017年10月18日17:05:08 修改
	var params = [];
	if (validate && validate.width) {
		params.push("vw=" + validate.width);
	}
	if (validate && validate.height) {
		params.push("vh=" + validate.height);
	}
	if (saveInfo && saveInfo.width) {
		params.push("sw=" + saveInfo.width);
	}
	if (saveInfo && saveInfo.height) {
		params.push("sh=" + saveInfo.height);
	}
	if (watermark) {
		params.push("wm=" + encodeURIComponent(watermark))
	}
	var getParam = params.length > 0 ? params.join("&") : null;
	___createUpLoadDalogNew___(
		"image",
		getParam,
		blankURL, 
		callback,
		function(c, form) {
			var file = c.files[0];
			//马少博 2017年10月18日13:40:15修改图片上传功能
			var des = $("#imgUploadBlock").find("#descript");
			try {
				des.empty();
				var w = file.width;
				var h = file.height;
				if (w > 200 || h > 160) {
					if (w > h) {
						var rate = h / w;
						w = 200;
						h = 200 * rate;
					} else {
						var rate = w / h;
						h = 160;
						w = 160 * rate;
					}
				}
				$("<img>").attr("src", file.url)
				.css({
					// width: w,
					//  height: h, 
					//  float: "left", 
					// clear: "none"
				})
				.addClass('img-responsive img-thumbnail')
				.appendTo(des);

				var info = $("<div class='img-info'></div>").appendTo(des);

				info.html(
					"<b>图像类型</b>：" + file.mime + "<br/>" +
					"<b>文件大小</b>：" + file.fileSize + "<br/>" +
					"<b>图像宽度</b>：" + file.width + "px<br/>" +
					"<b>图像高度</b>：" + file.height + "px"
				);

				//控制模块的显示与隐藏
				newImgShow();
				$("#txtImgRemarkInfo").keydown(function (e) {
					var ev = document.all ? window.event : e;
					if (ev.keyCode == 13) {
						$("#saveImgInfoBlock").click();
						return false; //防止其他默认事件
					}
				  });
				
				//添加备注按钮,进行ajax操作
				$("#saveImgInfoBlock").one('click',function (e) { 
					e.preventDefault();
					var url=file.url;
					var remark=$("#imgUploadBlock").find("#txtImgRemarkInfo").val().trim()?$("#imgUploadBlock").find("#txtImgRemarkInfo").val().trim():url.substring(url.lastIndexOf('/')+1).substring(0,url.substring(url.lastIndexOf('/')+1).indexOf('.'));//备注信息
					$("#imgUploadBlock").find("#spanImgInfo").text(remark);
					//TODO 进行ajax操作
					$.ajax({
					  type: "POST",
					  url: "knowledge/article/insertOrDelImage",
					  data: {
						 remark:remark,
						 url:url 
					  },
					  dataType: "json",
					  success: function(data, textStatus, jqXHR) {
						if (data != null && data != "") {
						  if (data.success) {
							var imgId= data.bean;//用于删除操作
							$("#imgUploadBlock").
							find("#btnImgDelete").
							attr("data-delete-id",imgId);
							getImgListByDate(getToday());
							//TODO getToday() 重新请求今天的URL

						  } 
						}  
					  } 
					});

					infoImgShow();
				});

				$("#btnImgUse").unbind();
				//点击应用按钮进行操作
				$("#btnImgUse").on('click',function (e) { 
					e.preventDefault();
					//将原来的回调函数在___createUpLoadDalogNew___中调用,修改为在按钮中调用
					callback(c);
				});

				//点击删除按钮进行的操作
				$("#btnImgDelete").one('click',function (e) { 
					e.preventDefault();
					//删除操作
					var  deleteId=$(this).attr("data-delete-id");

					$.ajax({
						type: "POST",
						url: "knowledge/article/insertOrDelImage",
						data: {
						   id: deleteId
						},
						dataType: "json",
						success: function(data, textStatus, jqXHR) {
						  if (data != null && data != "") {
							if (data.success) {
							  imgBlockClear();
							  //TODO getToday() 重新请求今天的URL
							  getImgListByDate(getToday());
							} 
						  }  
						} 
					  });
				});
			} catch(e) {
				//控制模块的显示与隐藏
				infoImgShow();
			}
		});
			
	}

}

function imgBlockClear(){
	infoImgShow();

	var $imgBlock=$("#imgUploadBlock");//modal DOM对象
	$imgBlock.find("#descript").empty();
	$imgBlock.find("#useImgBlock").hide();//删除与使用两个按钮隐藏
	$imgBlock.find("#spanImgInfo").hide();
	$imgBlock.find("#remarkBlock").hide();
}
/**
 * 新增图片时控制DOM的显示与隐藏
 * 
 */
function newImgShow(){
	var $imgBlock=$("#imgUploadBlock");//modal DOM对象
	$imgBlock.find("#useImgBlock").hide();//删除与使用两个按钮隐藏
	$imgBlock.find("#saveImgInfoBlock").show();//保存备注信息按钮
	$imgBlock.find("#remarkBlock").show();//备注模块
	$imgBlock.find("#spanImgInfo").hide();//隐藏span
	$imgBlock.find("#txtImgRemarkInfo").show();//输入框
	$imgBlock.find("#txtImgRemarkInfo").val('').focus();//获得焦点
}

function infoImgShow(){
	var $imgBlock=$("#imgUploadBlock");//modal DOM对象
	$imgBlock.find("#txtImgRemarkInfo").hide();//输入框隐藏
	$imgBlock.find("#saveImgInfoBlock").hide();//保存备注按钮隐藏
	$imgBlock.find("#useImgBlock").show();//两个使用按钮显示
	$imgBlock.find("#remarkBlock").show();
	$imgBlock.find("#spanImgInfo").show();
}

///////////////////文件上传///////////////////////////////////
/**
 * 为某个按钮绑定上传文件
 * 
 * @param compress 是否压缩文件
 * @param blankURL 跨域异步所需的本地url地址
 * @param floor 新开窗口所属层数
 * @param callback 回调函数 
 */
function UploadFILE(compress, blankURL,floor,callback){
	var diag = new top.httc();
	diag.two = true;
	diag.Width = 400;
	diag.Height = 400;
	diag.Title = "上传文件";
	//经zdialog源码研究发现在zdialog打开的窗口下获取父级元素时用parent获取到的是顶层父级元素，所以得传过去打开窗口所属层数，便于在新开窗口下处理相应层数下的元素
	var url = projectPath + "/tool/toFileUpload?compress=Y&&blankURL="+blankURL+"&&floor="+floor+"&&callback="+callback;
	diag.URL = url;
	diag.CancelEvent = function(){ 
		diag.close();
	};
	diag.show();
}
/**
 * 上传资源文件
 * @param compress 是否压缩文件
 * @param blankURL 跨域异步所需的本地url地址
 * @param callback 上传结束后的回调方法，接受参数格式：{success: true/false, message: ..., files: [{url:..., mime:..., fileSize:...}]}
 * @returns
 */
var uploadResource = function(compress, blankURL, callback) {
	___createUpLoadDalog___("file", compress ? "compress=N": "compress=Y", blankURL, callback, function(c, form) {
		var file = c.files[0];
	//	form.find("#descript").html("访问地址：<a href='" + file.url + "' target='_blank'>" + file.url + "</a><br/>资源类型：" + file.mime + "<br/>资源大小：" + file.fileSize );
		form.find("#descript").html("资源类型：" + file.mime + "<br/>资源大小：" + file.fileSize );
		form.find("#fileUrl").html(file.url+"");
		form.find("#fileSize").html(file.fileSize+"");
	});
}

/**
 * 绘制资源上传对话框
 */
var ___createUpLoadDalog___ = function(type, params, blankURL, callback, showDescript) {
	var content = null;
  	var form = $("#uploadFileForm");
  	___doSubmit___(form, type, params, blankURL, function(c){
  		$("#zhongxin").show();
        $("#zhongxin2").hide();
  		if (c.success && c.files.length > 0) {
  			content = c;
  			try {showDescript(c, form);} catch(e){console.info(e);}
  			callback(content);
  		} else {
  			form.find("#descript").empty().append("<span style='color: red;'>" + c.message + "</span>");
  			content = null;
  		}
  	});
};

/**
* 绘制资源上传对话框
* 2017年10月18日16:12:09 马少博 修改
*/
var ___createUpLoadDalogNew___ = function(type, params, blankURL, callback, showDescript) {
   var content = null;
	 var form = $("#uploadFileForm");
	 ___doSubmit___(form, type, params, blankURL, function(c){
		 $("#zhongxin").show();
	   $("#zhongxin2").hide();
		 if (c.success && c.files.length > 0) {
			 content = c;
			 try {showDescript(c, form);} catch(e){console.info(e);}
			//  callback(content);
		 } else {
			 console.info($("#imgUploadBlock").find("#descript"));
			 $("#imgUploadBlock").find("#remarkBlock").hide();
			 $("#imgUploadBlock").find("#useImgBlock").hide();
			 $("#imgUploadBlock").find("#saveImgInfoBlock").hide();

			 $("#imgUploadBlock").find("#descript").empty().html("<span style='color: red;'><b>上传失败:</b><br>" + c.message + "</span>");
			 content = null;


		 }
	 });
};

var ___doSubmit___ = function(form, type, params, blankURL, callback) {
	var formAction = resourceHost + "upload/" + type + "?crossDomain=Y" + (params ? ("&" + params) : ""); 
		// 提交
		form.attr("action", formAction);
		form.attr("target", "up");
		var iframe = $("<iframe id=\"up\" src=\""+projectPath+"/tool/blank\" name=\"up\"></iframe>").appendTo(form);
		iframe.css({
			height: 0,
			width: 0,
			opacity: 0,
			position: "absolute",
	    	top: -100,
	    	right: -100
		}).data("first", true).on("load", function(){
			var that = $(this);
			if (that.data("first")) {
				this.contentWindow.location = blankURL || projectPath+"/tool/blank";
				that.data("first", false);
			} else {
				try {
	    			var content = JSON.parse(this.contentWindow.name);
					iframe.remove();
					try {callback(content)} catch(e){console.info(e);}
				} catch(e) {
					console.info(e);
				}
			}
		});
		form.submit();
};

////////上传微信客服头像

var uploadWXFace = function(accesstoken, account, blankURL, callback) {
	alert(4234)
	___createUpLoadDalogWX___(accesstoken, account, blankURL, callback, function(c, form) {
		var file = c.files[0];
		var des = form.find("#descriptWX");
		try {
			des.empty();
			var w = file.width;
			var h = file.height;
			if (w > 200 || h > 160) {
				if (w > h) {
					var rate = h / w;
					w = 200;
					h = 200 * rate;
				} else {
					var rate = w / h;
					h = 160;
					w = 160 * rate;
				}
			}
			$("<img>").attr("src", file.url).css({
				width: w, height: h, float: "left", clear: "none"
			}).appendTo(des);
			var info = $("<div style='width: 150; float: right; clear:none'></div>").appendTo(des);
			info.html(
				"图像类型：" + file.mime + "<br/>" +
				"文件大小：" + file.fileSize + "<br/>" +
				"图像宽度：" + file.width + "px<br/>" +
				"图像高度：" + file.height + "px"
			);
		} catch(e) {
			console.info(e);
		}
	});
}

var ___createUpLoadDalogWX___ = function(accesstoken,account, blankURL, callback, showDescript) {
	
	var content = null;
  	var form = $("#uploadWXFaceForm");
  	___doSubmitWX___(form, accesstoken, account, blankURL, function(c){
  		$("#zhongxin").show();
        $("#zhongxin2").hide();
  		if (c.success && c.files.length > 0) {
  			content = c;
  			try {showDescript(c, form);} catch(e){console.info(e);}
  			callback(content);
  		} else {
  			console.info(form.find("#descriptWX"));
  			form.find("#descriptWX").empty().append("<span style='color: red;'>" + c.message + "</span>");
  			content = null;
  		}
  	});
};

var ___doSubmitWX___ = function(form, token, account, blankURL, callback) {
	alert(token)
	alert(account)
	var formAction = "https://api.weixin.qq.com/customservice/kfaccount/uploadheadimg?access_token="+token+"&kf_account="+account; 
		// 提交
		form.attr("action", formAction);
		form.attr("target", "up");
		var iframe = $("<iframe id=\"up\" src=\""+projectPath+"/tool/blank\" name=\"up\"></iframe>").appendTo(form);
		iframe.css({
			height: 0,
			width: 0,
			opacity: 0,
			position: "absolute",
	    	top: -100,
	    	right: -100
		}).data("first", true).on("load", function(){
			var that = $(this);
			if (that.data("first")) {
				this.contentWindow.location = blankURL || projectPath+"/tool/blank";
				that.data("first", false);
			} else {
				try {
	    			var content = JSON.parse(this.contentWindow.name);
					iframe.remove();
					try {callback(content)} catch(e){console.info(e);}
				} catch(e) {
					console.info(e);
				}
			}
		});
		form.submit();
};

// 马少博 2017年10月19日11:27:47添加
  //清除图片错误上传信息
  function tttttclear(){
	$("#imgUploadBlock").find("#descript").find("span").html('');
  }
  function collapseDom1(arr) {
	var htmlStr = '';
	for (var index = 0; index < arr.length; index++) {
	  var element = arr[index];
	  var singleDomStr =
		'<div class="panel panel-default" data-date="' + element + '">' +
		'  <!-- 头 -->' +
		'  <div class="panel-heading" role="tab" id="title-' + element + '">' +
		'    <a role="button" class="click-title" data-toggle="collapse" data-parent="#accordion" href="#date-' + element + '" aria-expanded="true" aria-controls="date-' + element + '">' +
		element +
		'    </a>' +
		'  </div>' +
		'  <!-- 身体 -->' +
		'  <div id="date-' + element + '" class="panel-collapse collapse" role="tabpanel" aria-labelledby="title-' + element + '" data-date="' + element + '">' +
		'    <div class="panel-body img-body-block"> <h4 class="text-center">暂无结果</h4> </div>' +
		'  </div>' +
		'</div>';
	  htmlStr += singleDomStr;
	}
	window.top.$("#accordion").html(htmlStr);
  }

  /**
   * 循环获取日期(倒序)
   * @returns
   */
  Date.prototype.format = function() {
	var s = '';
	var mouth = (this.getMonth() + 1) >= 10 ? (this.getMonth() + 1) : ('0' + (this.getMonth() + 1));
	var day = this.getDate() >= 10 ? this.getDate() : ('0' + this.getDate());
	s += this.getFullYear() + '-'; // 获取年份。  
	s += mouth + "-"; // 获取月份。  
	s += day; // 获取日。  
	return (s); // 返回日期。  
  };
  //获取某个时间段内的每一天
  function getAll(begin, end) {
	var arr = [];
	var ab = begin.split("-");
	var ae = end.split("-");
	var db = new Date();
	db.setUTCFullYear(ab[0], ab[1] - 1, ab[2]);
	var de = new Date();
	de.setUTCFullYear(ae[0], ae[1] - 1, ae[2]);
	var unixDb = db.getTime();
	var unixDe = de.getTime();
	for (var k = unixDe; k >= unixDb;) {
	  arr.push((new Date(parseInt(k))).format());
	  k = k - 24 * 60 * 60 * 1000;
	}
	return arr;
  }
  //根据备注搜索图片列表
  function imgSearchByRemark1(){
	var remark=window.top.$("#imgUploadBlock").find("#txtImgSearchInput").val().trim();
	if(remark){
	$.ajax({
		type: "POST",
		url: "knowledge/article/searchImage",//TODO 修改此时链接
		data: {
		  remark:remark
		},
		dataType: "json",
		success: function(data, textStatus, jqXHR) {
		  if (data != null && data != "") {
			if (data.success) {
			  if(data.bean.length>0){
				var htmlStr="";
				for (var index = 0; index < data.bean.length; index++) {
				  var element = data.bean[index];
				  var singleImgDom=
					  '<div class="col-md-2 img-single-block">'+
						'<img src="'+element.url+'" alt="'+element.remark+'" data-imgId="'+element.id+'" onclick="tool.getUploadResult(this,\'666\',\'666\',\'\',\'\')";>'+
						'<p class="p-imgremark">'+element.remark+'</p>'+
					  '</div>';
				  htmlStr+=singleImgDom;
				}
				window.top.$("#accordion").html(htmlStr);
			  }
			  else {
				window.top.$("#accordion").html('<h4 class="text-center">暂无结果</h4>');
			}
			} else {
				window.top.$("#accordion").html('<h4 class="text-center">暂无结果</h4>');
			}
			
		  } else {
			window.top.$("#accordion").html('<h4 class="text-center">暂无结果</h4>');
		  }
		},
		error: function(response) {
			window.top.$("#accordion").html('<h4 class="text-center">暂无结果</h4>');
		},
		complete: function(xhr, textStatus) {
		  //NOTE 异步事件完成后需要操作的内容
		}
	  });
	}else{
		// 显示原来的日期列表
		//mashaobo 2017年10月19日13:23:04修改
        var arrays = getAll('2017-10-01', getToday());
        collapseDom(arrays);
	}
  }
  //点下边备注的时候  模拟点一下图片  
  function preimgclick(dom){
	$(dom).prev().click();
  }