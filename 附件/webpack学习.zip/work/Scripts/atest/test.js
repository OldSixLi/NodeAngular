import './test.css';
var Vue = require('./../vue');
import './../../Scripts/bootstrap-3.3.4.js'
// require('bootstrap-loader');
// import './../../Scripts/picker/bootstrap-datetimepicker.min.js'
import date from './../../template/date.vue';
import picker from './../../template/picker.vue';
window.Vue = Vue;
var vueapp = new Vue({
  el: "#vueapp",
  //数据部分 
  data: {
    bindData: "CF武器预览表",
    wuqi: ['盘龙', '火麒麟', '黑骑士', '黑龙', '雷神', '烈龙', '擎天', '毁灭']
  },
  //方法
  methods: {
    showHtml: function(e) {
      e.stopPropagation();
      console.log("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
      console.log($(e.target));
      console.log("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑");
    }
  },
  components: {
    'ht-date': date,
    'picker': picker
  },
  //过滤器
  filters: {},
  //实时计算
  computed: {},
  created: function() {}
});
$(function() {
  getUser();
  $("h1").on('click', function() {
    userTest();
    console.log('jquery运行中');
  });
});

function getUser() {
  alert("当前登录的用户是马少博")
}

function userTest() {
  alert('这个方法用户测试打包后的函数是否会执行')
}