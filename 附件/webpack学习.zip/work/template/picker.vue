
<template>
    <div id="time" class="form-group form-inline">
        <label class="select-box-title">时间：</label>
        <input class="form-control select-box-input" v-model="time" type="text" id="messageSendTime">
    </div>
</template>
<script>

     export default {
         name: 'picker',
        data:function () {
   return {
    time: ''
   }
  },
  methods: {
   dateDefind:function () {
    var d, s;
    var self = this;
    d = new Date();
    s = d.getFullYear() + "-";       //取年份
    s = s + (d.getMonth() + 1) + "-";//取月份
    s += d.getDate() + " ";     //取日期
    s += d.getHours() + ":";    //取小时
    s += d.getMinutes() + ":";  //取分
    s += d.getSeconds();     //取秒
    self.time = s;
    //初始化
    // $('#messageSendTime').datetimepicker({
    //  startDate: s,
    //  minView: "hour", //选择日期后，不会再跳转去选择时分秒
    //  language: 'zh-CN',
    //  format: 'yyyy-mm-dd hh:ii:ss',
    //  todayBtn: 1,
    //  autoclose: 1
    // });
    // //当选择器隐藏时，讲选择框只赋值给data里面的time
    // $('#messageSendTime').datetimepicker()
    //  .on('hide', function (ev) {
    //   var value = $("#messageSendTime").val();
    //   self.time = value;
    //  });
   }
  },
  mounted: function () {
   this.dateDefind();
  }
 }
</script>
<style scoped>
    .text-center {
        text-align: center;
    }
</style>


