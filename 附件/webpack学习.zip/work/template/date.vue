<template>
<h1 class="text-center"> {{name}}</h1>
</template>
<script> 
export default {
  name: 'biaoti',
  props:['titles'],
   data:function(){
     return {
       name:"当前测试的内容"
     }
   }
}
</script>
<style scoped>
.text-center{
  text-align: center;
}
</style>


