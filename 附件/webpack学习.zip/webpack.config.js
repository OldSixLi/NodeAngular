const htmlWebpackPlugin = require('html-webpack-plugin'); //installed via npm
const webpack = require('webpack');
const path = require('path');

module.exports = {
  entry: {
    // "common": __dirname + "/work/Scripts/CommonScript.js", //通用脚本
    // "angular": __dirname + "/work/Scripts/angular.js",
    // "bootstrap": __dirname + "/work/Scripts/bootstrap.min.js",
    // "jquery": __dirname + "/work/Scripts/jquery-1.9.1.min.js",
    // "vue": __dirname + "/work/Scripts/vue.js",
    // "w5c": __dirname + "/work/Scripts/w5cValidator.js",
    "test": __dirname + "/work/Scripts/atest/test.js",

    // "com": __dirname + "/app/com.js",
    // "headvue": __dirname + "/app/components/head.vue",
    // 'doc/jquery-with-plugin': __dirname + "/app/Scripts/webpack/jquery-webpack.js", //七牛云相关配置
    // 'doc/time': __dirname + "/app/Scripts/jquery.datetimepicker.full.min.js",
    // 'doc/angular-about': __dirname + "/app/Scripts/webpack/angular-webpack.js",
    // 'doc/qiniu': __dirname + "/app/Scripts/webpack/qiniu-webpack.js", //七牛云相关配置
    // 'doc/common': __dirname + "/app/Scripts/webpack/common.js",
    // 'doc/usermanage/acticityadd': __dirname + "/app/Scripts/doc/usermanage/acticityadd.js",
    // 'doc/usermanage/activitylist': __dirname + "/app/Scripts/doc/usermanage/activitylist.js",
  },
  output: {
    //打包后的文件存放的地方
    path: __dirname + "/public/",
    //打包后输出文件的文件名
    //NOTE: 此处的name对应entry中的key,
    // hash为每次打包生成的唯一的字符串 每次打包时就会更新
    // chunkhash为版本的版本号(MD5值) 文件更新时就会更新,文件如果不更新,即使打包也不会进行更新
    filename: "Scripts/[name].js",
  },
  externals: {
    // jquery: path.resolve(__dirname + '/work/Scripts/jquery-1.10.1.js'), //或者jquery:'jQuery'
    // $: path.resolve(__dirname + '/work/Scripts/jquery-1.10.1.js'), //或者jquery:'jQuery'
    // jQuery: path.resolve(__dirname + '/work/Scripts/jquery-1.10.1.js'), //或者jquery:'jQuery'
  },
  // 要启用什么loader
  module: {
    loaders: [{
        test: /\.(woff|woff2)(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'url?limit=10000&mimetype=application/font-woff'
      }, {
        test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'url?limit=10000&mimetype=application/octet-stream'
      }, {
        test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'file'
      }, {
        test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
        loader: "url?limit=10000&mimetype=image/svg+xml"
      }, {
        test: /\.js$/,
        loader: 'babel-loader',
        exclude: path.resolve(__dirname + "/node_modules/"), //解析成绝对路径
        include: __dirname + "/app/",
        //用什么loader处理  用哪种规则去处理js文件
        query: {
          presets: ['latest']
        }
      }, {
        test: /\.css$/,
        loader: "style-loader!css-loader",
      }, {
        test: /\.vue$/,
        use: [{
          loader: 'vue-loader',
          // options: {
          //   loaders: {
          //     js: 'babel-loader?{"presets":["latest"],"plugins": ["transform-object-rest-spread"]}',
          //     css: 'vue-style-loader!css-loader'
          //   }
          // }

        }],
        exclude: /node_modules/
      },
      {　　　　　　
        test: /\.(png|jpg|gif|svg)$/i,
        // loader: 'url-loader',
        //使用多个loader进行处理,模拟URL的编写形式,数组中的规则是从右到左

        loaders: [
          //此处大于2000b的图片就会被image-webpack-loader进行压缩
          'url-loader?limit=2000&name=image/[name]-[hash:5].[ext]',
          'image-webpack-loader'
          //此处必须是全名,否则报错(在这个插件中,对于不同类型的图片有不同的设置参数,可以更具体的处理压缩图片)
        ],
        //单个loader时使用下方设置
        // query: {
        //   limit: 200000,
        //   name: "image/[name]-[hash:5].[ext]" //打包后的文件名称
        // }　
      }
    ]
  },
  resolve: {
    alias: {
      'vue': __dirname + '/work/Scripts/vue.js',
      jquery: __dirname + '/work/Scripts/jquery-1.9.1.min.js'
    }
  },

  plugins: [
    // #3  添加活动页面
    new htmlWebpackPlugin({
      filename: "doc/SystemManage/AdminSetting.html",
      template: './work/UserDocs/SystemManage/AdminSetting.html',
      title: "管理员设置",
      inject: false, //是否添加到body中 (head|true|false)
      minify: {
        removeComments: true,
        collapseWhitespace: true, //删除空格
      },
      chunks: [
        // 'doc/jquery-with-plugin',
        // 'doc/angular-about',
        // 'doc/qiniu',
        // 'doc/common',
        // 'doc/usermanage/acticityadd',
        'common'
      ], //添加相关的依赖JS, 
    }), new htmlWebpackPlugin({
      filename: "doc/list.html",
      template: './work/UserDocs/AVue/list.html',
      title: "测试页面",
      inject: true, //是否添加到body中 (head|true|false)
      minify: {
        removeComments: true,
        collapseWhitespace: true, //删除空格
      },
      chunks: ['test'], //添加相关的依赖JS, 
    }),
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        warnings: false
      }
    }),
    // 插件名称只能用驼峰式。否则报错
    // #1
    // new htmlWebpackPlugin({
    //   filename: "doc/a-work.html",
    //   template: 'a.html',
    //   inject: false, //静态资源引入head头部,不自动引入,手动引入
    //   title: "A.html",
    //   date: new Date().getFullYear() + '/' +
    //     (new Date().getMonth() + 1) + '/' +
    //     new Date().getDate() + ' ' +
    //     new Date().getHours() + ':' +
    //     new Date().getMinutes() + ':' +
    //     new Date().getSeconds() + '',
    //   minify: {
    //     removeComments: true,
    //     collapseWhitespace: true, //删除空格
    //   }
    // }),
    // // #2
    // new htmlWebpackPlugin({
    //   filename: "doc/b-work.html",
    //   template: 'b.html',
    //   title: "B.html",

    //   inject: false,
    //   minify: {
    //     removeComments: false,
    //     collapseWhitespace: false, //删除空格
    //     // collapseInlineTagWhitespace: true, //删除空表字符
    //   },
    //   // chunks: ['test'], //添加相关的依赖JS, 

    // }),

  ]
}