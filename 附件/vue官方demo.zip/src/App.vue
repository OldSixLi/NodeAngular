
<template>
  <div id="app" class="texr-center">
    <row>
      <div class="col-md-4 col-md-offset-4">
        <div class="form-group">
          <ht-select></ht-select>
        </div>
      </div>
    </row>

    <row>
      <img src="./assets/logo.png">
      <h1>{{ msg }}</h1>
      <h2>组件标题</h2>
      <ul>
        <li v-for="x in 10">{{x}}</li>
      </ul>
      <h2>你们大家说是什么意思</h2>
      <ul>
        <li v-for="x in 20">{{x}}</li>
      </ul>
    </row>
  </div>
</template>

<script>
import HtSelect  from './model/select.vue';
import Row  from './model/row.vue'
  export default {
    name: 'app',
    data() {
      return {
        msg: 'Vue开始执行...'
      }
    },components:{
      HtSelect,Row
    }
  }
</script>

<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
  }
  h1,
  h2 {
    font-weight: normal;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    display: inline-block;
    margin: 0 10px;
  }
  a {
    color: #42b983;
  }
  .text-center{
    text-align: center;
    margin:0 auto;
  }
</style>
