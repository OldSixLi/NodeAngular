<template>
    <input type="text" class="form-control">
</template>
<script>
    export default {
        name: "ht-input",
        props: {  
        //对外获取的数据
        },
        data: function() {
        //组件内数据部分
        return {  
        }
        },
        mounted: function() {  
        //组件生成时调用
        },
        methods:{
        } 
    }
</script>
<style scoped> 

</style>