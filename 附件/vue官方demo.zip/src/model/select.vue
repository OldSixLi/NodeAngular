
<template>
    <select name="" id="" class="form-control">
        <option 
        v-bind:value="x" 
        v-for="x in ['张三','李四','王五']">{{x}}</option>
    </select>
</template>
<script>
    export default {
        name: "ht-select",
        props: {  
        //对外获取的数据
        },
        data: function() {
        //组件内数据部分
        return {  
        }
        },
        mounted: function() {  
        //组件生成时调用
        },
        methods:{
        } 
    }
</script>
<style scoped> 
select{
    border:1px solid #ddd;
}
</style>


