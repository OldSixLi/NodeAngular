import Vue from 'vue'
import App from './App.vue'
import htSelect from './model/select.vue';
import container from './model/container.vue';
import Row from './model/row.vue'

new Vue({
  el: '#app',
  data: {
    names: "张三丰"
  },
  // render: h => h(App),
  components: {
    App,
    htSelect,
    container,
    Row
  }
});