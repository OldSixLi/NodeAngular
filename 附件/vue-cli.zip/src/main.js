import Vue from 'vue'
import App from './App.vue'

new Vue({
  el: '#app',
  render: h => h(App)
})
Vue.component('name', {
  template: 'htmlstr',
  //对外获取的数据
  props: {},
  //组件内数据部分
  data: function() {
    return {}
  },
  //组件生成时调用
  mounted: function() {}
});
var name = new Vue({
  el: "#name ",
  //数据部分 
  data: {},
  //方法
  methods: {},
  //过滤器
  filters: {},
  //实时计算
  computed: {},
  //加载后立即执行的方法(created 这个钩子在实例被创建之后被调用)
  created: function() {}
});